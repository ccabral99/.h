package ar.edu.ucc.arqSoft.trabajoPractico.common.dto;

public class DtoEntity {

}
