package ar.edu.ucc.arqSoft.trabajoPractico.baseService.model;

import javax.persistence.Entity;

@Entity
public enum Genero {
 TERROR,COMEDIA;
}
