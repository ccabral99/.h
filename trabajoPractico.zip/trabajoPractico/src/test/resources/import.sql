-- You can use this file to load seed data into the database using SQL statements
insert into PELICULA (titulo, sinopsis, anio, genero) values ('Salta', 'Habia una', '2', 1);